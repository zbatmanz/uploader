<?php
date_default_timezone_set('Asia/Tehran');
ini_set("log_errors", "off");
error_reporting(0);

$DB = [
'dbname' => 'cldsite_God',
'username' => 'cldsite_gdm',
'password' => 'N(VD-mgn{hAk'
];


$apiKey = '7337603956:AAFuhwDB4_-1WeDxj5OdzpkrUb3EtAr7WH4';

$botUsername = 'new_bot_offbot';

$merchantID = 'a8d08b2c-a58d-40bc-abfb-808090067aab';

$webAddress = 'https://c-l.d71.site/4/';

$payments_log = -1002176769407;

$ToAcceptQuestion = -1002176769407;

$ToHaveQuestions = -1002176769407;

$first_coin_count = 10;

$refral_coin = 2;

$dev = 7354122540; ## admin dev

$BotAdmins = file("admin.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$LockChannelsUserName = file("channel_user.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$LockChannelsUserID = file("channel_id.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);


