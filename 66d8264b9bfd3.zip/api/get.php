<?php
include '../config.php';
$conn = $database;
$id = $_GET["id"];
$data = $conn->select("create", 
"*", [
    "id" => $id
]);
if ($data == null){
echo "<p>سروری موجود نمیباشد</p>";
}else{
echo json_encode($data[0]["url"],JSON_UNESCAPED_UNICODE);
}
?>